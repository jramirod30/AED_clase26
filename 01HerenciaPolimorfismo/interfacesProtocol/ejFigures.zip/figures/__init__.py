from .figure import IFigure
from .circularMirror import CircularMirror
from .photo import Photo
